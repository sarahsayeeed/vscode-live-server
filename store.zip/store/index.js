// Import required modules
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');

// Initialize Express app
const app = express();

// Set EJS as the view engine and specify views directory
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware to parse incoming request bodies
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the public directory
app.use(express.static('public'));
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/online-store-db', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.once('open', () => {
  console.log('Connected to MongoDB');
});

// Define MongoDB schema and model
const OrderSchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  address: String,
  city: String,
  postcode: String,
  province: String,
  products: [String],
  deliveryTime: String,
});
const Order = mongoose.model('Order', OrderSchema);

// Routes
app.get('/', (req, res) => {
  res.render('index'); // Render your index.ejs or other appropriate view
});

app.post('/submit-order', (req, res) => {
  const { name, email, phone, address, city, postcode, province, product1, product2, product3, deliveryTime } = req.body;

  // Create a new order document
  const newOrder = new Order({
    name,
    email,
    phone,
    address,
    city,
    postcode,
    province,
    products: [product1, product2, product3],
    deliveryTime,
  });

  // Save the order to MongoDB
  newOrder.save()
    .then(() => {
      res.redirect('/orders');
    })
    .catch((err) => {
      console.error(err);
      res.status(500).send('Error submitting order');
    });
});

app.get('/orders', (req, res) => {
  Order.find()
    .then((orders) => {
      res.render('orders', { orders });
    })
    .catch((err) => {
      console.error(err);
      res.status(500).send('Error fetching orders');
    });
});

// Start the server
const PORT = process.env.PORT || 3002;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
